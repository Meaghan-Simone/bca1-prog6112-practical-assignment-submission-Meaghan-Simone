/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculatorapp;

/**
 *
 * @author smdbs
 */
abstract class AdvCalculator {
public abstract double power(double base, double exponent);
public abstract double squareRoot(double number);
}
//(Farrell, 2022)