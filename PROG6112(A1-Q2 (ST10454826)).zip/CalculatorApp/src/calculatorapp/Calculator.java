/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculatorapp;

/**
 *
 * @author smdbs
 */
public class Calculator extends AdvCalculator implements Fuction{
    
    
    @Override
    public double add(double x, double y){
        return x + y;
    }
    
    //(Oracle,n.d)
    
    @Override
    public double subtraction(double x, double y){
        return x - y;
    }
    @Override
    public double multiply(double x, double y){
        return x * y;
    }
    @Override
    public double division(double x, double y){
        if(y == 0){
            System.out.print("Error");
        }
        return x/y;
    }
//(Farrell, 2018)
    @Override
    public double power(double base, double exponent) {
        return Math.pow(base, exponent);
    }

    @Override
    public double squareRoot(double number) {
        if (number < 0) {
            throw new IllegalArgumentException("Cannot calculate square root of a negative number.");
        }
        return Math.sqrt(number);
    }
}
//implements the nessessary calculating operation for the calculator Application