/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package calculatorapp;

/**
 *
 * @author smdbs
 */
interface Fuction {
abstract double add(double x, double y);
    abstract double subtraction(double x, double y);
    abstract double multiply(double x, double y);
    abstract double division(double x, double y);
}
//(Oracle,2019)