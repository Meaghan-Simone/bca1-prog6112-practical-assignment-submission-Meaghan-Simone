/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calculatorapp;

import java.util.Scanner;

/**
 *
 * @author smdbs
 */
public class CalculatorApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Calculator calculator = new Calculator();
        Scanner scanner = new Scanner(System.in);
         boolean continueCalculating = true;
        
        System.out.println("Calculator");
        System.out.println("**********");
        System.out.println("(1) ADD");
        System.out.println("(2) SUBTRACT");
        System.out.println("(3) DIVIDE");
        System.out.println("(4) SQUARE ROOT ");
        System.out.println("(4) POWER ");
          //displays to calculation options
        
        int choice = scanner.nextInt();
         //asking the user for what operation that wish to calculate 
          while (continueCalculating) {
         double result = 0;
         switch(choice){
             case 1:
                 System.out.println("Enter first number and second number:");
                result = calculator.add(scanner.nextDouble(), scanner.nextDouble());
                break;
             case 2:
                System.out.println("Enter first number and second number:");  
                result = calculator.subtraction(scanner.nextDouble(), scanner.nextDouble());
                break;
             case 3:
                System.out.println("Enter first number and second number:"); 
                result = calculator.multiply(scanner.nextDouble(), scanner.nextDouble());
                break;
             case 4:
                System.out.println("Enter first number and second number:");  
                result = calculator.division(scanner.nextDouble(), scanner.nextDouble());
                break;
             case 5:
                System.out.println("Enter base number first and the the exponent number:");
                result = calculator.squareRoot(scanner.nextDouble());
                break;
             case 6:
                System.out.println("Enter a number:");
                //(Farrell, 2018)
                  
                result = calculator.power(scanner.nextDouble(), scanner.nextDouble());
                break;
            }
        System.out.println("Result:"+ result);
      continueCalculating = scanner.next().equalsIgnoreCase("yes");
       //allows the user to constinue with the calculator application and calculate another sum
        }
        scanner.close();
    }
}
//bibliography 
//Interfaces (The JavaTM Tutorials > Learning the Java Language > Interfaces and Inheritance) (no date) docs.oracle.com. Available at: https://docs.oracle.com/javase/tutorial/java/IandI/createinterface.html.
// Oracle,and /or its affiliates and/or its affiliates. “Math (Java Platform SE 8 ).” Oracle.com, 11 Sept. 2019, docs.oracle.com/javase/8/docs/api/java/lang/Math.html.Oracle. 
//“Abstract Methods and Classes (the JavaTM Tutorials >Learning the Java Language > Interfaces and Inheritance).” Oracle.com, 2019, docs.oracle.com/javase/tutorial/java/IandI/abstract.html.
//Farrell, J. (2018). Java Programming, Loose-Leaf Version. Cengage Learning.
//Farrell, J. (2022). Java Programming.
//Java Switch - JavatPoint. (n.d.). www.javatpoint.com. https://www.javatpoint.com/java-switch
//The switch Statement (The JavaTM Tutorials > Learning the Java Language > Language Basics). (n.d.). https://docs.oracle.com/javase/tutorial/java/nutsandbolts/switch.html
//W3Schools.com. (n.d.). https://www.w3schools.com/java/ref_keyword_extends.asp
