/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import calculatorapp.Calculator;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author smdbs
 */
public class CalculatorTest {
    
    Calculator calculator = new Calculator();

    @Test
    public void testAdd() {
        assertEquals(8.0, calculator.add(5.0, 3.0), 0.0);
        assertEquals(-3.0, calculator.add(-4.0, 1.0), 0.0);
    }

    @Test
    public void testSubtraction() {
        assertEquals(1.0, calculator.subtraction(3.0, 2.0), 0.0);
        assertEquals(-3.0, calculator.subtraction(-1.0, 2.0), 0.0);
    }

    @Test
    public void testMultiply() {
        assertEquals(6.0, calculator.multiply(2.0, 3.0), 0.0);
        assertEquals(-2.0, calculator.multiply(-1.0, 2.0), 0.0);
    }

    @Test
    public void testDivision() {
        assertEquals(2.0, calculator.division(6.0, 3.0), 0.0);
        try {
            calculator.division(5.0, 0.0);
            fail("Error");
        } catch (IllegalArgumentException e) {
            assertEquals("Error", e.getMessage());
        }
    }

    @Test
    public void testPower() {
        assertEquals(8.0, calculator.power(2.0, 3.0), 0.0);
        assertEquals(1.0, calculator.power(5.0, 0.0), 0.0);
    }

    @Test
    public void testSquareRoot() {
        assertEquals(3.0, calculator.squareRoot(9.0), 0.0);
        try {
            calculator.squareRoot(-1.0);
            fail("error");
        } catch (IllegalArgumentException e) {
            assertEquals("Error", e.getMessage());
        }
    }
}