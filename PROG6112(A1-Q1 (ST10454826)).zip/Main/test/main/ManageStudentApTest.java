/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package main;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author smdbs
 */
class ManageStudentApTest {

    private final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

   @Test
    void setUp() {
        System.setOut(new PrintStream(outputStream));
        ManageStudentAp.students = new ArrayList<>(); // Reset the student list before each test
    }

    @Test
    void testSaveStudent() {
        String input = "123\nJohn Doe\n20\njohn.doe@example.com\nComputer Science\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));

        ManageStudentAp.saveStudent();

        assertEquals(1, ManageStudentAp.students.size());
        Student student = ManageStudentAp.students.get(0);
        assertEquals("123", student.getStudentId());
        assertEquals("STUDENT ID: 123\nSTUDENT NAME: John Doe\nSTUDENT AGE: 20\nSTUDENT EMAIL: john.doe@example.com\nSTUDENT COURSE: Computer Science", student.getDetails());
    }

    @Test
    void testSearchStudent_Found() {
        Student student = new Student("123", "John Doe", 20, "john.doe@example.com", "Computer Science");
        ManageStudentAp.students.add(student);

        String input = "123\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));

        ManageStudentAp.searchStudent();

        String expectedOutput = "STUDENT ID: 123\nSTUDENT NAME: John Doe\nSTUDENT AGE: 20\nSTUDENT EMAIL: john.doe@example.com\nSTUDENT COURSE: Computer Science\n";
        assertTrue(outputStream.toString().contains(expectedOutput));
    }

    @Test
    void testSearchStudent_NotFound() {
        String input = "123\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));

        ManageStudentAp.searchStudent();

        assertTrue(outputStream.toString().contains("Student with Student Id: 123 was not found!"));
    }

    @Test
    void testDeleteStudent() {
        Student student = new Student("123", "John Doe", 20, "john.doe@example.com", "Computer Science");
        ManageStudentAp.students.add(student);

        String input = "123\ny\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));

        ManageStudentAp.deleteStudent();

        assertEquals(0, ManageStudentAp.students.size());
        assertTrue(outputStream.toString().contains("Student with Student Id: 123 WAS deleted!"));
    }

    @Test
    void testDeleteStudent_NotFound() {
        String input = "123\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));

        ManageStudentAp.deleteStudent();

        assertTrue(outputStream.toString().contains("Student with Student Id: 123 was not found!"));
    }

 @Test
    public void testStudentAge_StudentAgeValid() {
        int age = 20;

        // Ensure the age is valid
        assertTrue(age >= 16);
    }

    @Test
    public void testStudentAge_StudentAgeInvalid() {
        int age = 15;

        // Ensure the age is invalid
        assertFalse(age >= 16);
    }

    @Test
    public void testStudentAge_StudentAgeInvalidCharacter() {
        String ageInput = "abc";

        try {
            Integer.parseInt(ageInput);
            fail("NumberFormatException expected");
        } catch (NumberFormatException e) {
            // Expected exception caught
        }
    }
}
    
   
