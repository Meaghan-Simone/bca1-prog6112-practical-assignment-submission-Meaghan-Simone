/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author smdbs
 */
public class Main {
     

    public static void main(String[] args) {
     ManageStudentAp management = new ManageStudentAp();  
     management.firstOption();
     management.showMenu();
     //(Farrell, 2018)
     
    }
}
//Bibliography 
//Farrell, J. (2018). Java Programming, Loose-Leaf Version. Cengage Learning.
//Farrell, J. (2022). Java Programming.
//Java Switch - JavatPoint. (n.d.). www.javatpoint.com. https://www.javatpoint.com/java-switch
//The switch Statement (The JavaTM Tutorials > Learning the Java Language > Language Basics). (n.d.). https://docs.oracle.com/javase/tutorial/java/nutsandbolts/switch.html
//W3Schools.com. (n.d.). https://www.w3schools.com/java/ref_keyword_extends.asp

