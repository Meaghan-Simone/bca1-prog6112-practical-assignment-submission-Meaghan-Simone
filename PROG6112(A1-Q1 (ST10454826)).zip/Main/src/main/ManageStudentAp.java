/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import java.util.ArrayList;
    // {W3Schools, 2019} 
import java.util.Scanner;

/**
 *
 * @author smdbs
 */
public class ManageStudentAp {
     static ArrayList<Student> students = new ArrayList<Student>(); //{W3Schools, 2019} 
        //array list to capture the students
     private static Scanner scanner = new Scanner(System.in);

    static String firstOption() {
        String input = "";
        while (true) {
            System.out.println("Enter (1) to launch menu or any other key to exit");
            input = scanner.nextLine();
            if (!input.equals("1")) {
                break;
            }
            showMenu();
        }
        return input;
    }

    static String showMenu() {
        System.out.println("Please select one of the following menu items:");
        System.out.println("(1) Capture a new student");
        System.out.println("(2) Search for student");
        System.out.println("(3) Delete a student");
        System.out.println("(4) Print student report");
        System.out.println("(5) Exit application");

        String choice = scanner.nextLine();
        switch (choice) {
            case "1" -> saveStudent();
            case "2" -> searchStudent();
            case "3" -> deleteStudent();
            case "4" -> studentReport();
            case "5" -> System.exit(0);
            default -> System.out.println("Invalid choice. Please try again.");
        }
        return choice;
    }

    static Student saveStudent() {
        System.out.println("CAPTURE A NEW STUDENT");
        System.out.println("****************************");

        System.out.print("Enter the student ID: ");
        String id = scanner.nextLine();

        System.out.print("Enter the student name: ");
        String name = scanner.nextLine();

        int age = 0;
        while (true) {
            System.out.print("Enter the student age: ");
            String ageInput = scanner.nextLine();
            try {
                age = Integer.parseInt(ageInput);
                if (age >= 16) {
                    break;
                } else {
                    System.out.println("You have entered an incorrect student age! Please re-enter the student age.");
                }
            } catch (NumberFormatException e) {
                System.out.println("You have entered an incorrect student age! Please re-enter the student age.");
            }
        }

        System.out.print("Enter the student email: ");
        String email = scanner.nextLine();

        System.out.print("Enter the student course: ");
        String course = scanner.nextLine();

        Student newStudent = new Student(id, name, age, email, course);
        students.add(newStudent);
        System.out.println("Student details have been successfully saved.");
        return newStudent;
    }

    static Student searchStudent() {
        System.out.print("Enter the student id to search: ");
        String studentId = scanner.nextLine();
        for (Student student : students) {
            if (student.getStudentId().equals(studentId)) {
                System.out.println(student.getDetails());
                return student;
            }
        }
        System.out.println("Student with Student Id: " + studentId + " was not found!");
        return null;
    }

    static boolean deleteStudent() {
        System.out.print("Enter the student id to delete: ");
        String studentId = scanner.nextLine();

        for (Student student : students) {
            if (student.getStudentId().equals(studentId)) {
                System.out.print("Are you sure you want to delete student " + studentId + " from the system? Yes (y) to delete: ");
                String confirmation = scanner.nextLine();
                if (confirmation.equalsIgnoreCase("y")) {
                    students.remove(student);
                    System.out.println("Student with Student Id: " + studentId + " WAS deleted!");
                    return true;
                }
            }
        }
        System.out.println("Student with Student Id: " + studentId + " was not found!");
        return false;
    }

    public static String studentReport() {
        StringBuilder report = new StringBuilder("STUDENT REPORT\n");
        for (Student student : students) {
            report.append(student).append("\n");
        }
        System.out.println(report.toString());
        return report.toString();
    }
}


