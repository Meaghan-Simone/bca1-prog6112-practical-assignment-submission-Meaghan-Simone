/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

/**
 *
 * @author smdbs
 */
public class Student extends Person{
    private final String studentId;
    private final String course;

    public Student(String studentId, String name, int age, String email, String course) {
        super(name, age, email);
        this.studentId = studentId;
        this.course = course;
    }
    //(Farrell, 2018)

    public String getStudentId() {
        return studentId;
    }

    public String getDetails() {
        return "STUDENT ID: " + studentId + "\nSTUDENT NAME: " + name + 
               "\nSTUDENT AGE: " + age + "\nSTUDENT EMAIL: " + email + 
               "\nSTUDENT COURSE: " + course;
    }
}

